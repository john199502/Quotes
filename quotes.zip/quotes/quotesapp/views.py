from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User, Quotes

def index(request):
    return render(request, "index.html")
def register(request):
    def register(request):
        errors = User.objects.basic_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
             messages.error(request, value)
        return redirect("/")
    else:
        hash1 = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        u = User.objects.create(firstname=request.POST['firstname'], lastname=request.POST['lastname'], email=request.POST['email'], password=hash1)
        request.session['userid'] = u.id
        return redirect("/quotes")
def login(request):
    user = User.objects.filter(email=request.POST['email'])
    errors = {}
    if not user:
        errors['email'] = "Invalid email or password"
    else:
        logged_user = user[0]
        if bcrypt.checkpw(request.POST['password'].encode(), logged_user.password.encode()):
            request.session['userid'] = logged_user.id
            return redirect("/books")
        else:
            errors['password'] = "Invalid email or password"
    
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")
    else:
        return redirect("/quotes")
def quotes(request):
    context = {
        "loggedin" = User.objects.get(id= request.session ['userid'])
    }
    return render(request, "quotes.html", context)
def create(request):
    return redirect("/quotes")
def editquote(request, id):
    return render(request, "edit.html")
def userquotes(request, id):
    return render(request, "user.html")
def delete(request, id):
    return redirect("/quotes")

