from django.urls import path
from . import views
urlpatterns = [
    path('', views.index),
    path('register', views.register),
    path('login', views.login),
    path('quotes', views.quotes),
    path('quotes/<int:id>', views.editquote),
    path('user/<int:id>', views.userquotes),
    path('quotes/create', views.create),
    path('quotes/delete/<int:id>', views.delete),
]