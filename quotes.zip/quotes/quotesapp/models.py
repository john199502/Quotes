from __future__ import unicode_literals
import re
from django.db import models

class UserManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}
        
        if len(postData['name']) < 2:
            errors['name'] = "Name must be at least 2 characters!"
        if len(postData['alias']) < 2:
            errors['alias'] = "Alias must be at least 2 characters!"

        #Email regex validation
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(postData['email']):           
            errors['email'] = "Invalid email address!"
        
        all_users = User.objects.all()
        for x in all_users:
            if x.email == postData['email']:
                errors['email'] = "Email must be unique!"
        
        if len(postData['password']) < 8:
            errors['password'] = "Password must be at least 8 characters!"
        
        if postData['password'] != postData['cpassword']:
            errors['password'] = "Password does not match password confirm!"
        return errors
class User(models.Model):
    firstname = models.CharField( max_length= 30)
    lastname = models.CharField( max_length= 30)
    email = models.CharField( max_length= 150)
    password = models.CharField( max_length= 150)
    created_at = models.DateTimeField(auto_now_add=True)
    created_at = models.DateTimeField(auto_now=True)
class Quote(models.Model):
    quotedby = models.CharField(max_length= 30)
    message = models.CharField(max_length= 255)
    userquotes = models.ForeignKey(user, related_name="quotes", on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    created_at = models.DateTimeField(auto_now=True)

